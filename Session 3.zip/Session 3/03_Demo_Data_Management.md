# Volume Mounts
***
#### Specified in the Dockerfile

* Invoked through the VOLUME instruction
* Creates a mountpoint
* Holds the volume as externally mounted volumes 
* Outlives the Container must be deleted manually
#### Show information about container volumes
```
docker container inspect 
```
* The mounted volumes
* The destination of the the mount in the container
* Physical location of the mount
```
docker container run -d --name -e MYSQL_ALLOW_EMPTY_PASSWORD=True  –v mysql-db:/var/lib/mysql mysql
```
* Will create a volume with the name („mysql-db“)
* Allows for better handling
